package com.example.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.model.NoraProfile
import com.example.model.ProxyConfig
import com.example.model.ProxyProtocol
import com.example.model.TimeConfig
import com.example.model.TimeMode
import com.example.model.UAMode
import com.example.model.UserAgentConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ProfileRepository(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("nora_profiles_prefs", Context.MODE_PRIVATE)
    private val _profiles = MutableStateFlow<List<NoraProfile>>(emptyList())
    val profiles: StateFlow<List<NoraProfile>> = _profiles.asStateFlow()

    private val _activeProfileId = MutableStateFlow<String>("")
    val activeProfileId: StateFlow<String> = _activeProfileId.asStateFlow()

    init {
        loadProfiles()
    }

    private fun loadProfiles() {
        val jsonStr = prefs.getString("saved_profiles_json", null)
        if (jsonStr.isNullOrBlank()) {
            // Seed with realistic default and standard SNS profiles
            val defaultList = listOf(
                NoraProfile(
                    id = "profile_default",
                    name = "Default (General)",
                    colorHex = "#3B82F6",
                    isDefault = true,
                    site = "",
                    proxy = ProxyConfig(enabled = false, protocol = ProxyProtocol.DIRECT),
                    userAgent = UserAgentConfig(mode = UAMode.DEFAULT),
                    time = TimeConfig(mode = TimeMode.DEVICE)
                ),
                NoraProfile(
                    id = "profile_x_main",
                    name = "X / Twitter Main",
                    colorHex = "#0EA5E9",
                    site = "x.com",
                    proxy = ProxyConfig(enabled = false, protocol = ProxyProtocol.DIRECT),
                    userAgent = UserAgentConfig(mode = UAMode.PRESET, selectedId = "android_chrome_128"),
                    time = TimeConfig(mode = TimeMode.DEVICE)
                ),
                NoraProfile(
                    id = "profile_x_alt",
                    name = "X / Twitter Alt (Proxy US)",
                    colorHex = "#6366F1",
                    site = "x.com",
                    proxy = ProxyConfig(
                        enabled = true,
                        protocol = ProxyProtocol.HTTP,
                        host = "us-proxy.example.com",
                        port = 8080
                    ),
                    userAgent = UserAgentConfig(mode = UAMode.PRESET, selectedId = "ios_safari_17"),
                    time = TimeConfig(mode = TimeMode.MANUAL, timezoneId = "America/New_York")
                ),
                NoraProfile(
                    id = "profile_reddit_lurk",
                    name = "Reddit Privacy",
                    colorHex = "#F97316",
                    site = "reddit.com",
                    proxy = ProxyConfig(
                        enabled = true,
                        protocol = ProxyProtocol.SOCKS5,
                        host = "127.0.0.1",
                        port = 9050
                    ),
                    userAgent = UserAgentConfig(mode = UAMode.RANDOM),
                    time = TimeConfig(mode = TimeMode.PROXY)
                ),
                NoraProfile(
                    id = "profile_threads",
                    name = "Threads / Meta",
                    colorHex = "#EC4899",
                    site = "threads.net",
                    proxy = ProxyConfig(enabled = false),
                    userAgent = UserAgentConfig(mode = UAMode.DEFAULT),
                    time = TimeConfig(mode = TimeMode.DEVICE)
                )
            )
            _profiles.value = defaultList
            _activeProfileId.value = defaultList.first().id
            persistProfiles()
        } else {
            try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<NoraProfile>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(deserializeProfile(obj))
                }
                _profiles.value = list
                val active = prefs.getString("active_profile_id", "") ?: ""
                _activeProfileId.value = if (active.isNotBlank() && list.any { it.id == active }) {
                    active
                } else {
                    list.firstOrNull()?.id ?: ""
                }
            } catch (_: Exception) {
                // fallback
            }
        }
    }

    fun setActiveProfile(id: String) {
        if (_profiles.value.any { it.id == id }) {
            _activeProfileId.value = id
            prefs.edit().putString("active_profile_id", id).apply()
            // Increment usage
            val updated = _profiles.value.map {
                if (it.id == id) it.copy(lastUsedAt = System.currentTimeMillis(), usageCount = it.usageCount + 1)
                else it
            }
            _profiles.value = updated
            persistProfiles()
        }
    }

    fun getActiveProfile(): NoraProfile? {
        return _profiles.value.find { it.id == _activeProfileId.value } ?: _profiles.value.firstOrNull()
    }

    fun saveProfile(profile: NoraProfile) {
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == profile.id }
        if (index >= 0) {
            current[index] = profile.copy(updatedAt = System.currentTimeMillis())
        } else {
            current.add(profile.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
        }
        _profiles.value = current
        persistProfiles()
    }

    fun duplicateProfile(sourceId: String): NoraProfile? {
        val source = _profiles.value.find { it.id == sourceId } ?: return null
        val newProfile = source.copy(
            id = "profile_" + UUID.randomUUID().toString().take(8),
            name = "${source.name} (Copy)",
            isDefault = false,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            lastUsedAt = System.currentTimeMillis(),
            usageCount = 0
        )
        saveProfile(newProfile)
        return newProfile
    }

    fun deleteProfile(id: String): Boolean {
        val current = _profiles.value
        val toDelete = current.find { it.id == id } ?: return false
        if (toDelete.isDefault) return false // Cannot delete default profile
        val updated = current.filter { it.id != id }
        _profiles.value = updated
        if (_activeProfileId.value == id) {
            _activeProfileId.value = updated.firstOrNull()?.id ?: ""
            prefs.edit().putString("active_profile_id", _activeProfileId.value).apply()
        }
        persistProfiles()
        return true
    }

    fun toggleProxy(id: String): Boolean {
        val current = _profiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0) {
            val p = current[index]
            val newProxy = p.proxy.copy(enabled = !p.proxy.enabled)
            current[index] = p.copy(proxy = newProxy, updatedAt = System.currentTimeMillis())
            _profiles.value = current
            persistProfiles()
            return newProxy.enabled
        }
        return false
    }

    private fun persistProfiles() {
        val array = JSONArray()
        for (p in _profiles.value) {
            array.put(serializeProfile(p))
        }
        prefs.edit().putString("saved_profiles_json", array.toString()).apply()
    }

    private fun serializeProfile(p: NoraProfile): JSONObject {
        val obj = JSONObject()
        obj.put("id", p.id)
        obj.put("name", p.name)
        obj.put("colorHex", p.colorHex)
        obj.put("isDefault", p.isDefault)
        obj.put("site", p.site)
        obj.put("createdAt", p.createdAt)
        obj.put("updatedAt", p.updatedAt)
        obj.put("lastUsedAt", p.lastUsedAt)
        obj.put("usageCount", p.usageCount)

        // Proxy
        val proxyObj = JSONObject()
        proxyObj.put("enabled", p.proxy.enabled)
        proxyObj.put("protocol", p.proxy.protocol.name)
        proxyObj.put("host", p.proxy.host)
        proxyObj.put("port", p.proxy.port)
        proxyObj.put("username", p.proxy.username)
        proxyObj.put("password", p.proxy.password)
        proxyObj.put("pacUrl", p.proxy.pacUrl)
        obj.put("proxy", proxyObj)

        // UA
        val uaObj = JSONObject()
        uaObj.put("mode", p.userAgent.mode.name)
        uaObj.put("selectedId", p.userAgent.selectedId)
        uaObj.put("browserFamily", p.userAgent.browserFamily)
        uaObj.put("osFamily", p.userAgent.osFamily)
        uaObj.put("customUA", p.userAgent.customUA)
        obj.put("userAgent", uaObj)

        // Time
        val timeObj = JSONObject()
        timeObj.put("mode", p.time.mode.name)
        timeObj.put("timezoneId", p.time.timezoneId)
        timeObj.put("offsetMinutes", p.time.offsetMinutes)
        timeObj.put("simulatedTimezone", p.time.simulatedTimezone)
        obj.put("time", timeObj)

        return obj
    }

    private fun deserializeProfile(obj: JSONObject): NoraProfile {
        val proxyObj = obj.optJSONObject("proxy") ?: JSONObject()
        val uaObj = obj.optJSONObject("userAgent") ?: JSONObject()
        val timeObj = obj.optJSONObject("time") ?: JSONObject()

        val proxy = ProxyConfig(
            enabled = proxyObj.optBoolean("enabled", false),
            protocol = try {
                ProxyProtocol.valueOf(proxyObj.optString("protocol", ProxyProtocol.DIRECT.name))
            } catch (_: Exception) { ProxyProtocol.DIRECT },
            host = proxyObj.optString("host", ""),
            port = proxyObj.optInt("port", 8080),
            username = proxyObj.optString("username", ""),
            password = proxyObj.optString("password", ""),
            pacUrl = proxyObj.optString("pacUrl", "")
        )

        val ua = UserAgentConfig(
            mode = try {
                UAMode.valueOf(uaObj.optString("mode", UAMode.DEFAULT.name))
            } catch (_: Exception) { UAMode.DEFAULT },
            selectedId = uaObj.optString("selectedId", ""),
            browserFamily = uaObj.optString("browserFamily", "Chrome"),
            osFamily = uaObj.optString("osFamily", "Android"),
            customUA = uaObj.optString("customUA", "")
        )

        val time = TimeConfig(
            mode = try {
                TimeMode.valueOf(timeObj.optString("mode", TimeMode.DEVICE.name))
            } catch (_: Exception) { TimeMode.DEVICE },
            timezoneId = timeObj.optString("timezoneId", "UTC"),
            offsetMinutes = timeObj.optInt("offsetMinutes", 0),
            simulatedTimezone = timeObj.optString("simulatedTimezone", "UTC")
        )

        return NoraProfile(
            id = obj.optString("id", UUID.randomUUID().toString()),
            name = obj.optString("name", "Unnamed Profile"),
            colorHex = obj.optString("colorHex", "#3B82F6"),
            isDefault = obj.optBoolean("isDefault", false),
            site = obj.optString("site", ""),
            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
            lastUsedAt = obj.optLong("lastUsedAt", System.currentTimeMillis()),
            usageCount = obj.optInt("usageCount", 0),
            proxy = proxy,
            userAgent = ua,
            time = time
        )
    }
}
