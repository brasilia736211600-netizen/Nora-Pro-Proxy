import { StyleProp } from 'react-native'

export type OnLoadEventPayload = {
  canGoBack?: boolean
  url?: string
  title?: string
  icon?: string
}

export type OnMessageEventPayload = {
  payload: string
}

export type NoraViewProps = {
  className?: string
  style?: StyleProp<any>
  ref: React.Ref<any>
  useragent: string
  partition?: string
  profile?: string
  inspectable?: boolean
  allowpopups?: string
  src?: string
  scriptOnStart?: string
  /** Injected before page scripts run (WebRTC guard). Native platforms only. */
  scriptOnDocumentStart?: string
  textZoom?: number
  /** Reload the page when the user drags down from the top. Native platforms only. */
  pullToRefresh?: boolean
  /** Emit `scroll` messages per touch sample. Android only; off unless a setting reads them. */
  scrollEvents?: boolean
  onLoad?: (event: { nativeEvent: OnLoadEventPayload }) => void
  onMessage?: (event: { nativeEvent: OnMessageEventPayload }) => void
}
